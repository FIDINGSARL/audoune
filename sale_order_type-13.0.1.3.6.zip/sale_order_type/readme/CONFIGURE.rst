To configure Sale Order Types you need to:

#. Go to **Sales > Configuration > Sales Orders Types**
#. Create a new sale order type with all the settings you want
